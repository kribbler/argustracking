=== Carousel Ultimate ===
Contributors: themepoints
Donate link:http://themepoints.com
Tags:  carousel, carousel's , carousel shortcode , responsive carousel, wordpress carousel, carousel logo, logo carousel, image carousel, carousel gallery, touch carousel, easy carousel, gallery carousel, nice carousel, client carousel.
Requires at least: 3.8
Tested up to: 4.1.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy Responsive Shortcode carousel for WordPress.

== Description ==
This plugin allows you to use shortcode to display carousel post or page. you can easily create carousel using shortcode.


### Carousel by http://themepoints.com

* [Live demo!&raquo;](http://themepoints.com)

<strong>Plugin Features </strong>

* Shortcode System.
* Touch Enable.
* Fully responsive.
* All Browser support.
* Auto play Enable.
* Unlimited Carousel.
* Use via short-code.
* Support post or page.
* Enable tinymce button.
* And many more.



== Installation ==

1. Install as regular WordPress plugin.
2. Go your Pluings setting via WordPress Dashboard and activate it.
3. After activate plugin you will see a button on the post or page visual editor called Add Carousel Shortcode. Click on it, from there you will receive the shortcode.<br />
<br /><br />

<strong>How to use short-code?</strong><br />


<br /><br />





== Screenshots ==

1. screenshot-1
2. screenshot-2
3. screenshot-3

== Upgrade Notice ==


== Frequently Asked Questions ==


== Changelog ==


= 1.0 =
* Initial release
